// middleware/auth.js - ตรวจสอบสถานะการ Login จาก Session
function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบ' });
  }
  return res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
}

function requireAdmin(req, res, next) {
  if (!req.session || !req.session.user) {
    if (req.originalUrl.startsWith('/api/')) return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบ' });
    return res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
  }
  if (req.session.user.role !== 'admin') {
    if (req.originalUrl.startsWith('/api/')) return res.status(403).json({ error: 'เฉพาะผู้ดูแลระบบเท่านั้น' });
    return res.status(403).send('403 - เฉพาะผู้ดูแลระบบเท่านั้น');
  }
  next();
}

module.exports = { requireLogin, requireAdmin };
