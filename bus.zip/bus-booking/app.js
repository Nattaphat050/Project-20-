// app.js - จุดเริ่มต้นของเซิร์ฟเวอร์ (Express.js)
const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const { requireLogin, requireAdmin } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// ---------- Middleware ----------
app.use(express.json());                 // อ่าน JSON body
app.use(cookieParser());                 // อ่าน Cookie (req.cookies)
app.use(session({                        // Session: เก็บสถานะ Login ฝั่งเซิร์ฟเวอร์
  name: 'busid',
  secret: process.env.SESSION_SECRET || 'change-this-secret-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 2 } // 2 ชั่วโมง
}));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- REST API ----------
app.use('/api/auth', require('./routes/auth'));
app.use('/api/trips', require('./routes/trips'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/admin', require('./routes/admin'));

// ---------- Pages ----------
const view = name => (req, res) => res.sendFile(path.join(__dirname, 'views', name));
app.get('/', view('index.html'));
app.get('/login', view('login.html'));
app.get('/register', view('register.html'));
app.get('/trip/:id', view('trip.html'));
app.get('/my-bookings', requireLogin, view('my-bookings.html'));
app.get('/admin', requireAdmin, view('admin.html'));

// ---------- Errors ----------
app.use('/api', (req, res) => res.status(404).json({ error: 'ไม่พบ API ที่ร้องขอ' }));
app.use((req, res) => res.status(404).send('404 - ไม่พบหน้าที่ต้องการ'));
app.use((err, req, res, next) => {
  console.error(err);
  if (req.originalUrl.startsWith('/api/')) return res.status(500).json({ error: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
  res.status(500).send('เกิดข้อผิดพลาดของเซิร์ฟเวอร์');
});

app.listen(PORT, () => console.log(`Bus Booking System running at http://localhost:${PORT}`));
