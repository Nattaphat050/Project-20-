# System Documentation — ระบบจองรถโดยสารออนไลน์

## 1. System Overview
เว็บแอปพลิเคชันจองรถโดยสาร ทำงานแบบ Client–Server: ฝั่ง Client (HTML/CSS/JavaScript) เรียก REST API
ของ Express.js ด้วย `fetch` แล้วอัปเดตหน้าจอด้วย DOM ฝั่ง Server ตรวจสอบข้อมูล ตรวจสิทธิ์ด้วย Session และบันทึกข้อมูลลง `data/db.json`

**ขอบเขต:** ค้นหาเที่ยว เลือกที่นั่ง จอง ยกเลิก และจัดการข้อมูลโดย Admin
**นอกขอบเขต:** ระบบชำระเงินจริง การส่งอีเมล/SMS และการออกตั๋ว QR

## 2. User Roles
| Role | สิทธิ์ |
|---|---|
| ผู้เยี่ยมชม | ค้นหา และดูผังที่นั่ง |
| User | จอง ดูประวัติ และยกเลิกการจองของตนเอง |
| Admin | จัดการเที่ยวรถ ดูหรือยกเลิกการจองทั้งหมด ลบผู้ใช้ |

## 3. Functional Requirements
1. สมัครสมาชิก (ตรวจ username ซ้ำ ความยาวรหัสผ่าน) / Login / Logout
2. ค้นหาเที่ยวรถตามต้นทาง ปลายทาง วันที่ และเรียงตามเวลา ราคา ที่นั่งว่าง
3. แสดงผังที่นั่ง (ว่าง / เลือกอยู่ / ไม่ว่าง) และคำนวณราคารวมทันที
4. จองได้ 1–4 ที่นั่ง Server ตรวจที่นั่งซ้ำเพื่อกันการจองชนกัน
5. ยกเลิกการจอง (ก่อนรถออก) สถานะเปลี่ยนเป็น cancelled และที่นั่งกลับมาว่าง
6. Admin: CRUD เที่ยวรถ ดูรายการจองทั้งหมด ลบผู้ใช้ (ห้ามลบเที่ยว/ผู้ใช้ที่ยังมีการจองอยู่)

## 4. Data Structure (data/db.json)
- **users**: id, username, password (scrypt hash + salt), fullName, role, createdAt
- **trips**: id, origin, destination, date, time, price, busType, totalSeats
- **bookings**: id, userId, tripId, seats[], passengerName, phone, totalPrice, status (confirmed/cancelled), createdAt, cancelledAt
- ความสัมพันธ์: users 1—N bookings, trips 1—N bookings

## 5. Cookies และ Session
| กลไก | ชื่อ | ใช้เพื่อ |
|---|---|---|
| Session | `busid` (HttpOnly) | เก็บสถานะ Login ฝั่ง Server (id, role) ใช้ใน middleware `requireLogin` / `requireAdmin` หมดอายุ 2 ชั่วโมง |
| Cookie | `lastSearch` | จำเงื่อนไขค้นหาล่าสุด 7 วัน เติมในฟอร์มหน้าแรก |
| Cookie | `rememberedUser` | จำ username เมื่อติ๊ก "จดจำ" ไว้เติมในหน้า Login (30 วัน) |

## 6. User Flow
**User:** เข้าหน้าแรก → ค้นหา → เลือกเที่ยว → (ถ้ายังไม่ Login ไปหน้า Login แล้วกลับมา) → เลือกที่นั่ง → กรอกชื่อ/เบอร์ → ยืนยัน → ดูใน "การจองของฉัน" → ยกเลิกได้
**Admin:** Login → หน้าจัดการระบบ → เพิ่ม/แก้ไข/ลบเที่ยว • ดูการจอง • ลบผู้ใช้ → Logout

## 7. Site Map
```
/                 ค้นหาเที่ยวรถ
├── /login        เข้าสู่ระบบ
├── /register     สมัครสมาชิก
├── /trip/:id     เลือกที่นั่งและจอง
├── /my-bookings  การจองของฉัน (ต้อง Login)
└── /admin        จัดการระบบ (เฉพาะ Admin)
```

## 8. Screenshots
(แนบภาพหน้าจอ: หน้าค้นหา, ผังที่นั่ง, การจองของฉัน, หน้า Admin)

## 9. วิธีการใช้งาน
1. `npm install` แล้ว `npm start` เปิด http://localhost:3000
2. ทดสอบฝั่งผู้ใช้ด้วย `user / user123` และฝั่งผู้ดูแลด้วย `admin / admin123`
