// my-bookings.js - ประวัติการจองและยกเลิกการจอง
initNav();
const listEl = document.getElementById('list');
const msg = document.getElementById('msg');
const dialog = document.getElementById('cancelDialog');
let bookings = [];
let filter = 'all';
let pendingCancelId = null;

function render() {
  const shown = bookings.filter(b => filter === 'all' || b.status === filter);
  if (!shown.length) {
    listEl.replaceChildren(h('div', { class: 'card empty' }, 'ไม่มีรายการจอง'));
    return;
  }
  listEl.replaceChildren(...shown.map(b => {
    const t = b.trip;
    const cancelled = b.status === 'cancelled';
    return h('div', { class: 'card trip' },
      h('div', {},
        h('div', { class: 'route' }, t ? `${t.origin} → ${t.destination}` : '(เที่ยวรถถูกลบ)'),
        t && h('div', { class: 'meta' }, `${fmtDate(t.date)} • ออกเวลา ${t.time} น.`),
        h('div', { class: 'meta' }, `ที่นั่ง ${b.seats.join(', ')} • ผู้โดยสาร ${b.passengerName} • โทร ${b.phone}`),
        h('div', { class: 'meta' }, `เลขที่การจอง #${b.id} • จองเมื่อ ${fmtDateTime(b.createdAt)}`),
        h('span', { class: 'badge ' + (cancelled ? 'cancel' : 'ok') }, cancelled ? 'ยกเลิกแล้ว' : 'ยืนยันแล้ว')
      ),
      h('div', {},
        h('div', { class: 'price' }, fmtMoney(b.totalPrice)),
        b.canCancel && h('button', { class: 'btn btn-danger btn-sm', onclick: () => askCancel(b) }, 'ยกเลิกการจอง')
      )
    );
  }));
}

function askCancel(b) {
  pendingCancelId = b.id;
  document.getElementById('cancelText').textContent =
    `ต้องการยกเลิกการจอง #${b.id} (ที่นั่ง ${b.seats.join(', ')}) ใช่หรือไม่?`;
  dialog.showModal();
}

async function load() {
  try {
    bookings = (await api('/api/bookings/mine')).bookings;
    render();
  } catch (err) {
    if (err.status === 401) return (location.href = '/login?next=/my-bookings');
    showMessage(msg, err.message);
  }
}

document.getElementById('filters').addEventListener('click', e => {
  const btn = e.target.closest('.tab');
  if (!btn) return;
  filter = btn.dataset.filter;
  document.querySelectorAll('#filters .tab').forEach(t => t.classList.toggle('active', t === btn));
  render();
});

document.getElementById('cancelNo').addEventListener('click', () => dialog.close());
document.getElementById('cancelYes').addEventListener('click', async () => {
  dialog.close();
  try {
    const res = await api('/api/bookings/' + pendingCancelId, { method: 'DELETE' });
    showMessage(msg, res.message, 'success');
  } catch (err) {
    showMessage(msg, err.message);
  }
  load();
});

load();
