// login.js - ฟอร์มเข้าสู่ระบบ
initNav();
const msg = document.getElementById('msg');
const usernameEl = document.getElementById('username');

// อ่าน Cookie rememberedUser ที่เซิร์ฟเวอร์ตั้งไว้ตอน login ครั้งก่อน
const remembered = getCookie('rememberedUser');
if (remembered) {
  usernameEl.value = remembered;
  document.getElementById('remember').checked = true;
}

document.getElementById('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  hideMessage(msg);
  try {
    const { user } = await api('/api/auth/login', {
      method: 'POST',
      body: {
        username: usernameEl.value.trim(),
        password: document.getElementById('password').value,
        remember: document.getElementById('remember').checked
      }
    });
    // กลับไปหน้าที่ต้องการก่อนถูกส่งมา login (รับเฉพาะ path ภายในเว็บ)
    const next = new URLSearchParams(location.search).get('next');
    const safeNext = next && next.startsWith('/') && !next.startsWith('//') ? next : null;
    location.href = safeNext || (user.role === 'admin' ? '/admin' : '/');
  } catch (err) {
    showMessage(msg, err.message);
  }
});
