// register.js - ฟอร์มสมัครสมาชิก (ตรวจข้อมูลฝั่ง Client แล้วตรวจซ้ำที่ Server)
initNav();
const msg = document.getElementById('msg');

document.getElementById('registerForm').addEventListener('submit', async e => {
  e.preventDefault();
  hideMessage(msg);
  const password = document.getElementById('password').value;
  if (password !== document.getElementById('confirm').value) {
    return showMessage(msg, 'รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน');
  }
  try {
    await api('/api/auth/register', {
      method: 'POST',
      body: {
        fullName: document.getElementById('fullName').value,
        username: document.getElementById('username').value.trim(),
        password
      }
    });
    showMessage(msg, 'สมัครสมาชิกสำเร็จ กำลังพาไปหน้าเข้าสู่ระบบ...', 'success');
    setTimeout(() => (location.href = '/login'), 1200);
  } catch (err) {
    showMessage(msg, err.message);
  }
});
