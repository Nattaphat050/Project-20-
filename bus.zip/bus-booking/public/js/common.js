// common.js - ฟังก์ชันที่ใช้ร่วมกันทุกหน้า (DOM helpers, เรียก API, แถบเมนู)

// เรียก API แล้วแปลงเป็น JSON; ถ้า error จะ throw Error พร้อมข้อความจากเซิร์ฟเวอร์
async function api(url, { method = 'GET', body } = {}) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    credentials: 'same-origin',
    body: body ? JSON.stringify(body) : undefined
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* ไม่มี body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || 'เกิดข้อผิดพลาด');
    err.status = res.status;
    throw err;
  }
  return data;
}

// สร้าง element แบบปลอดภัย (ใช้ textContent ป้องกัน XSS)
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

const fmtDate = d => new Date(d + 'T00:00:00').toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric', weekday: 'short' });
const fmtMoney = n => Number(n).toLocaleString('th-TH') + ' บาท';
const fmtDateTime = iso => new Date(iso).toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' });

function showMessage(el, text, type = 'error') {
  el.textContent = text;
  el.className = 'alert alert-' + type;
  el.classList.remove('hidden');
}
function hideMessage(el) { el.classList.add('hidden'); }

function getCookie(name) {
  const m = document.cookie.split('; ').find(c => c.startsWith(name + '='));
  return m ? decodeURIComponent(m.split('=').slice(1).join('=')) : null;
}

// สร้างแถบเมนูตามสถานะ Login (ข้อมูลมาจาก Session ผ่าน /api/auth/me)
async function initNav() {
  const nav = document.getElementById('nav');
  let user = null;
  try { user = (await api('/api/auth/me')).user; } catch (e) { /* ignore */ }

  const inner = h('div', { class: 'inner' }, h('a', { class: 'brand', href: '/' }, '🚌 จองรถโดยสาร'));
  inner.append(h('a', { href: '/' }, 'ค้นหาเที่ยวรถ'));
  if (user) {
    inner.append(h('a', { href: '/my-bookings' }, 'การจองของฉัน'));
    if (user.role === 'admin') inner.append(h('a', { href: '/admin' }, 'จัดการระบบ'));
    inner.append(
      h('span', { class: 'hello' }, 'สวัสดี, ' + user.fullName),
      h('button', {
        onclick: async () => { await api('/api/auth/logout', { method: 'POST' }); location.href = '/'; }
      }, 'ออกจากระบบ')
    );
  } else {
    inner.append(h('a', { href: '/login' }, 'เข้าสู่ระบบ'), h('a', { href: '/register' }, 'สมัครสมาชิก'));
  }
  nav.className = 'navbar';
  nav.replaceChildren(inner);
  return user;
}
