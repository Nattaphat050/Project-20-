// trip.js - หน้าเลือกที่นั่งและยืนยันการจอง
const MAX_SEATS = 4;
const tripId = Number(location.pathname.split('/').pop());
const seatMapEl = document.getElementById('seatMap');
const msg = document.getElementById('msg');
const confirmBtn = document.getElementById('confirmBtn');
let trip = null;
let bookedSeats = [];
let selected = [];   // ที่นั่งที่ผู้ใช้กำลังเลือก
let user = null;

function updateSummary() {
  const sorted = [...selected].sort((a, b) => a - b);
  document.getElementById('selectedSeats').textContent = sorted.length ? sorted.join(', ') : '-';
  document.getElementById('totalPrice').textContent = fmtMoney(trip.price * sorted.length);
  confirmBtn.disabled = !user || sorted.length === 0;
}

function toggleSeat(n) {
  if (selected.includes(n)) {
    selected = selected.filter(s => s !== n);
  } else {
    if (selected.length >= MAX_SEATS) return showMessage(msg, `เลือกได้สูงสุด ${MAX_SEATS} ที่นั่งต่อการจอง`);
    selected.push(n);
  }
  hideMessage(msg);
  renderSeats();
}

// สร้างผังที่นั่งด้วย DOM: แถวละ 4 ที่นั่ง (ซ้าย 2 + ทางเดิน + ขวา 2)
function renderSeats() {
  const rows = [];
  for (let start = 1; start <= trip.totalSeats; start += 4) {
    const cells = [];
    for (let i = 0; i < 4; i++) {
      const n = start + i;
      if (i === 2) cells.push(h('div'));            // ทางเดิน
      if (n > trip.totalSeats) { cells.push(h('div', { class: 'seat-empty' })); continue; }
      const taken = bookedSeats.includes(n);
      const isSel = selected.includes(n);
      cells.push(h('button', {
        type: 'button',
        class: 'seat' + (taken ? ' taken' : '') + (isSel ? ' selected' : ''),
        disabled: taken,
        'aria-label': `ที่นั่ง ${n}`,
        onclick: () => toggleSeat(n)
      }, n));
    }
    rows.push(h('div', { class: 'seat-row' }, ...cells));
  }
  seatMapEl.replaceChildren(...rows);
  updateSummary();
}

async function loadTrip() {
  const data = await api('/api/trips/' + tripId);
  trip = data.trip;
  bookedSeats = data.bookedSeats;
  selected = selected.filter(s => !bookedSeats.includes(s));
  document.getElementById('tripRoute').textContent = `${trip.origin} → ${trip.destination}`;
  document.getElementById('tripMeta').textContent = `${fmtDate(trip.date)} • ออกเวลา ${trip.time} น. • ${trip.busType}`;
  document.getElementById('tripPrice').textContent = fmtMoney(trip.price) + ' / ที่นั่ง';
  renderSeats();
}

document.getElementById('clearBtn').addEventListener('click', () => {
  selected = [];
  hideMessage(msg);
  renderSeats();
});

document.getElementById('bookForm').addEventListener('submit', async e => {
  e.preventDefault();
  hideMessage(msg);
  if (!selected.length) return showMessage(msg, 'กรุณาเลือกที่นั่งอย่างน้อย 1 ที่นั่ง');
  confirmBtn.disabled = true;
  try {
    const { booking } = await api('/api/bookings', {
      method: 'POST',
      body: {
        tripId: trip.id,
        seats: selected,
        passengerName: document.getElementById('passengerName').value,
        phone: document.getElementById('phone').value.trim()
      }
    });
    document.getElementById('content').replaceChildren(
      h('div', { class: 'card' },
        h('div', { class: 'alert alert-success' }, `จองสำเร็จ! เลขที่การจอง #${booking.id}`),
        h('p', {}, `${trip.origin} → ${trip.destination} | ${fmtDate(trip.date)} เวลา ${trip.time} น.`),
        h('p', {}, `ที่นั่ง: ${booking.seats.join(', ')} | ผู้โดยสาร: ${booking.passengerName}`),
        h('p', {}, h('strong', {}, 'ราคารวม: ' + fmtMoney(booking.totalPrice))),
        h('a', { class: 'btn', href: '/my-bookings' }, 'ดูการจองของฉัน'), ' ',
        h('a', { class: 'btn btn-secondary', href: '/' }, 'ค้นหาเที่ยวรถอื่น')
      )
    );
  } catch (err) {
    showMessage(msg, err.message);
    if (err.status === 409) { selected = []; await loadTrip(); } // ที่นั่งถูกจองไปแล้ว: โหลดผังใหม่
    else updateSummary();
  }
});

(async function init() {
  user = await initNav();
  if (user) {
    document.getElementById('passengerName').value = user.fullName;
  } else {
    document.getElementById('loginLink').href = '/login?next=' + encodeURIComponent(location.pathname);
    document.getElementById('loginNotice').classList.remove('hidden');
  }
  try {
    await loadTrip();
    document.getElementById('content').classList.remove('hidden');
  } catch (err) {
    showMessage(document.getElementById('pageMsg'), err.message);
  }
})();
