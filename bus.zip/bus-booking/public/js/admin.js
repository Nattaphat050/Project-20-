// admin.js - หน้าจัดการระบบสำหรับ Admin (CRUD เที่ยวรถ, ดูการจอง, จัดการผู้ใช้)
initNav();
const msg = document.getElementById('msg');
const tripDialog = document.getElementById('tripDialog');
const confirmDialog = document.getElementById('confirmDialog');
const dlgMsg = document.getElementById('dlgMsg');
let trips = [];
let editingId = null;       // null = เพิ่มใหม่, ตัวเลข = แก้ไข
let confirmAction = null;

// ---------- Tabs ----------
document.getElementById('tabs').addEventListener('click', e => {
  const btn = e.target.closest('.tab');
  if (!btn) return;
  document.querySelectorAll('#tabs .tab').forEach(t => t.classList.toggle('active', t === btn));
  ['trips', 'bookings', 'users'].forEach(n =>
    document.getElementById('tab-' + n).classList.toggle('hidden', n !== btn.dataset.tab));
  hideMessage(msg);
  ({ trips: loadTrips, bookings: loadBookings, users: loadUsers })[btn.dataset.tab]();
});

function ask(text, action) {
  document.getElementById('confirmText').textContent = text;
  confirmAction = action;
  confirmDialog.showModal();
}
document.getElementById('confirmNo').addEventListener('click', () => confirmDialog.close());
document.getElementById('confirmYes').addEventListener('click', async () => {
  confirmDialog.close();
  try {
    const res = await confirmAction();
    showMessage(msg, res.message, 'success');
  } catch (err) {
    showMessage(msg, err.message);
  }
  refreshCurrent();
});

function refreshCurrent() {
  const active = document.querySelector('#tabs .tab.active').dataset.tab;
  ({ trips: loadTrips, bookings: loadBookings, users: loadUsers })[active]();
}

const row = (...cells) => h('tr', {}, ...cells.map(c => h('td', {}, c)));

// ---------- Trips ----------
function renderTrips() {
  const q = document.getElementById('tripSearch').value.trim();
  const shown = trips.filter(t => !q || t.origin.includes(q) || t.destination.includes(q));
  document.getElementById('tripsBody').replaceChildren(...shown.map(t => row(
    t.id, `${t.origin} → ${t.destination}`, fmtDate(t.date), t.time, fmtMoney(t.price), t.busType,
    `${t.bookedCount}/${t.totalSeats}`,
    h('div', { class: 'actions' },
      h('button', { class: 'btn btn-sm', onclick: () => openTripForm(t) }, 'แก้ไข'),
      h('button', { class: 'btn btn-danger btn-sm', onclick: () =>
        ask(`ลบเที่ยวรถ #${t.id} (${t.origin} → ${t.destination}) ใช่หรือไม่?`,
          () => api('/api/admin/trips/' + t.id, { method: 'DELETE' })) }, 'ลบ')
    )
  )));
}

async function loadTrips() {
  try { trips = (await api('/api/admin/trips')).trips; renderTrips(); }
  catch (err) { showMessage(msg, err.message); }
}

function openTripForm(t) {
  editingId = t ? t.id : null;
  hideMessage(dlgMsg);
  document.getElementById('tripDialogTitle').textContent = t ? `แก้ไขเที่ยวรถ #${t.id}` : 'เพิ่มเที่ยวรถ';
  document.getElementById('f_origin').value = t ? t.origin : '';
  document.getElementById('f_destination').value = t ? t.destination : '';
  document.getElementById('f_date').value = t ? t.date : '';
  document.getElementById('f_time').value = t ? t.time : '';
  document.getElementById('f_price').value = t ? t.price : '';
  document.getElementById('f_seats').value = t ? t.totalSeats : 40;
  document.getElementById('f_busType').value = t ? t.busType : '';
  tripDialog.showModal();
}

document.getElementById('addTripBtn').addEventListener('click', () => openTripForm(null));
document.getElementById('tripCancel').addEventListener('click', () => tripDialog.close());
document.getElementById('tripSearch').addEventListener('input', renderTrips);

document.getElementById('tripForm').addEventListener('submit', async e => {
  e.preventDefault();
  hideMessage(dlgMsg);
  const body = {
    origin: document.getElementById('f_origin').value,
    destination: document.getElementById('f_destination').value,
    date: document.getElementById('f_date').value,
    time: document.getElementById('f_time').value,
    price: document.getElementById('f_price').value,
    totalSeats: document.getElementById('f_seats').value,
    busType: document.getElementById('f_busType').value
  };
  try {
    await api(editingId ? '/api/admin/trips/' + editingId : '/api/admin/trips',
      { method: editingId ? 'PUT' : 'POST', body });
    tripDialog.close();
    showMessage(msg, editingId ? 'แก้ไขเที่ยวรถเรียบร้อย' : 'เพิ่มเที่ยวรถเรียบร้อย', 'success');
    loadTrips();
  } catch (err) {
    showMessage(dlgMsg, err.message);
  }
});

// ---------- Bookings ----------
async function loadBookings() {
  try {
    const { bookings } = await api('/api/admin/bookings');
    const body = document.getElementById('bookingsBody');
    if (!bookings.length) {
      body.replaceChildren(h('tr', {}, h('td', { colspan: 8, class: 'empty' }, 'ยังไม่มีรายการจอง')));
      return;
    }
    body.replaceChildren(...bookings.map(b => {
      const t = b.trip;
      const cancelled = b.status === 'cancelled';
      return row(
        b.id, `${b.username} (${b.passengerName})`,
        t ? `${t.origin} → ${t.destination}` : '(เที่ยวรถถูกลบ)',
        t ? `${fmtDate(t.date)} ${t.time}` : '-',
        b.seats.join(', '), fmtMoney(b.totalPrice),
        h('span', { class: 'badge ' + (cancelled ? 'cancel' : 'ok') }, cancelled ? 'ยกเลิกแล้ว' : 'ยืนยันแล้ว'),
        !cancelled && h('button', { class: 'btn btn-danger btn-sm', onclick: () =>
          ask(`ยกเลิกการจอง #${b.id} ของ ${b.username} ใช่หรือไม่?`,
            () => api('/api/bookings/' + b.id, { method: 'DELETE' })) }, 'ยกเลิก')
      );
    }));
  } catch (err) { showMessage(msg, err.message); }
}

// ---------- Users ----------
async function loadUsers() {
  try {
    const { users } = await api('/api/admin/users');
    document.getElementById('usersBody').replaceChildren(...users.map(u => row(
      u.id, u.username, u.fullName,
      h('span', { class: 'badge' }, u.role === 'admin' ? 'Admin' : 'User'),
      u.bookingCount,
      u.role !== 'admin' && h('button', { class: 'btn btn-danger btn-sm', onclick: () =>
        ask(`ลบผู้ใช้ ${u.username} ใช่หรือไม่?`,
          () => api('/api/admin/users/' + u.id, { method: 'DELETE' })) }, 'ลบ')
    )));
  } catch (err) { showMessage(msg, err.message); }
}

loadTrips();
