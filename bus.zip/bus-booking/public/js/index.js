// index.js - หน้าค้นหาเที่ยวรถ
const originEl = document.getElementById('origin');
const destEl = document.getElementById('destination');
const dateEl = document.getElementById('date');
const sortEl = document.getElementById('sortBy');
const resultsEl = document.getElementById('results');
const countEl = document.getElementById('resultCount');
let currentTrips = [];

function render() {
  const sorted = [...currentTrips];
  if (sortEl.value === 'price') sorted.sort((a, b) => a.price - b.price);
  else if (sortEl.value === 'seats') sorted.sort((a, b) => b.availableSeats - a.availableSeats);
  else sorted.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

  countEl.textContent = `พบ ${sorted.length} เที่ยว`;
  if (!sorted.length) {
    resultsEl.replaceChildren(h('div', { class: 'card empty' }, 'ไม่พบเที่ยวรถตามเงื่อนไขที่ค้นหา'));
    return;
  }
  resultsEl.replaceChildren(...sorted.map(t => {
    const full = t.availableSeats === 0;
    return h('div', { class: 'card trip' },
      h('div', {},
        h('div', { class: 'route' }, `${t.origin} → ${t.destination}`),
        h('div', { class: 'meta' }, `${fmtDate(t.date)} • ออกเวลา ${t.time} น.`),
        h('div', { class: 'meta' }, h('span', { class: 'badge' }, t.busType), ' ',
          h('span', { class: 'badge ' + (full ? 'full' : 'ok') }, full ? 'เต็มแล้ว' : `ว่าง ${t.availableSeats}/${t.totalSeats} ที่นั่ง`))
      ),
      h('div', {},
        h('div', { class: 'price' }, fmtMoney(t.price)),
        full ? h('span', { class: 'meta' }, 'ที่นั่งเต็ม')
             : h('a', { class: 'btn', href: '/trip/' + t.id }, 'เลือกที่นั่ง')
      )
    );
  }));
}

async function search() {
  const params = new URLSearchParams();
  if (originEl.value) params.set('origin', originEl.value);
  if (destEl.value) params.set('destination', destEl.value);
  if (dateEl.value) params.set('date', dateEl.value);
  try {
    currentTrips = (await api('/api/trips?' + params)).trips;
    render();
  } catch (e) {
    resultsEl.replaceChildren(h('div', { class: 'alert alert-error' }, e.message));
  }
}

async function init() {
  initNav();
  const loc = await api('/api/trips/locations');
  loc.origins.forEach(o => originEl.append(h('option', { value: o }, o)));
  loc.destinations.forEach(d => destEl.append(h('option', { value: d }, d)));
  dateEl.min = new Date().toISOString().slice(0, 10);

  // ใช้ Cookie "lastSearch" เติมเงื่อนไขการค้นหาครั้งก่อน
  const { lastSearch } = await api('/api/trips/last-search');
  if (lastSearch) {
    originEl.value = lastSearch.origin || '';
    destEl.value = lastSearch.destination || '';
    dateEl.value = lastSearch.date || '';
    const note = document.getElementById('lastSearchNote');
    note.textContent = 'แสดงผลตามการค้นหาครั้งล่าสุดของคุณ (จดจำด้วย Cookie)';
    note.classList.remove('hidden');
  }
  search();
}

document.getElementById('searchForm').addEventListener('submit', e => { e.preventDefault(); search(); });
document.getElementById('resetBtn').addEventListener('click', () => {
  originEl.value = ''; destEl.value = ''; dateEl.value = '';
  document.getElementById('lastSearchNote').classList.add('hidden');
  search();
});
sortEl.addEventListener('change', render);
init();
