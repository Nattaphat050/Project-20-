// routes/auth.js - สมัครสมาชิก / Login / Logout (ใช้ Session + Cookie)
const express = require('express');
const db = require('../db');
const router = express.Router();

const THIRTY_DAYS = 1000 * 60 * 60 * 24 * 30;

// POST /api/auth/register
router.post('/register', (req, res) => {
  const { username, password, fullName } = req.body || {};
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username || '')) {
    return res.status(400).json({ error: 'ชื่อผู้ใช้ต้องเป็น a-z, 0-9, _ ความยาว 3-20 ตัวอักษร' });
  }
  if (typeof password !== 'string' || password.length < 6) {
    return res.status(400).json({ error: 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร' });
  }
  if (typeof fullName !== 'string' || fullName.trim().length < 2) {
    return res.status(400).json({ error: 'กรุณากรอกชื่อ-นามสกุล' });
  }
  if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(409).json({ error: 'ชื่อผู้ใช้นี้ถูกใช้แล้ว' });
  }
  const user = {
    id: db.nextId('users'), username, password: db.hashPassword(password),
    fullName: fullName.trim(), role: 'user', createdAt: new Date().toISOString()
  };
  db.users.push(user);
  db.save();
  res.status(201).json({ message: 'สมัครสมาชิกสำเร็จ' });
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { username, password, remember } = req.body || {};
  const user = db.users.find(u => u.username === username);
  if (!user || typeof password !== 'string' || !db.verifyPassword(password, user.password)) {
    return res.status(401).json({ error: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }
  // สร้าง session ใหม่หลัง login (ป้องกัน session fixation)
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'เกิดข้อผิดพลาดของระบบ' });
    req.session.user = { id: user.id, username: user.username, fullName: user.fullName, role: user.role };

    // Cookie: จดจำชื่อผู้ใช้ไว้เติมในหน้า Login ครั้งต่อไป
    if (remember) {
      res.cookie('rememberedUser', user.username, { maxAge: THIRTY_DAYS, sameSite: 'lax' });
    } else {
      res.clearCookie('rememberedUser');
    }
    res.json({ user: req.session.user });
  });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('busid');
    res.json({ message: 'ออกจากระบบแล้ว' });
  });
});

// GET /api/auth/me - ให้หน้าเว็บตรวจว่าใครกำลัง Login อยู่
router.get('/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

module.exports = router;
