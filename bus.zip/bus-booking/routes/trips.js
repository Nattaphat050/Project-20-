// routes/trips.js - ค้นหา / ดูรายละเอียดเที่ยวรถ (ไม่ต้อง Login)
const express = require('express');
const db = require('../db');
const router = express.Router();

// helper: คืนที่นั่งที่ถูกจองแล้ว (เฉพาะการจองที่ยังไม่ยกเลิก)
function bookedSeatsOf(tripId) {
  return db.bookings
    .filter(b => b.tripId === tripId && b.status === 'confirmed')
    .flatMap(b => b.seats);
}

function departureOf(trip) {
  return new Date(`${trip.date}T${trip.time}:00`);
}

function withAvailability(trip) {
  const booked = bookedSeatsOf(trip.id).length;
  return { ...trip, bookedCount: booked, availableSeats: trip.totalSeats - booked, departed: departureOf(trip) < new Date() };
}

// GET /api/trips/locations - รายชื่อต้นทาง/ปลายทางสำหรับ dropdown
router.get('/locations', (req, res) => {
  const origins = [...new Set(db.trips.map(t => t.origin))].sort();
  const destinations = [...new Set(db.trips.map(t => t.destination))].sort();
  res.json({ origins, destinations });
});

// GET /api/trips/last-search - อ่านค่า Cookie "lastSearch" ที่เซิร์ฟเวอร์เคยตั้งไว้
router.get('/last-search', (req, res) => {
  let last = null;
  try { last = req.cookies.lastSearch ? JSON.parse(req.cookies.lastSearch) : null; } catch (e) { last = null; }
  res.json({ lastSearch: last });
});

// GET /api/trips?origin=&destination=&date=
router.get('/', (req, res) => {
  const { origin = '', destination = '', date = '' } = req.query;

  // Cookie: จำเงื่อนไขการค้นหาล่าสุดไว้ 7 วัน
  if (origin || destination || date) {
    res.cookie('lastSearch', JSON.stringify({ origin, destination, date }), {
      maxAge: 1000 * 60 * 60 * 24 * 7, sameSite: 'lax'
    });
  }

  const now = new Date();
  const result = db.trips
    .filter(t => (!origin || t.origin === origin))
    .filter(t => (!destination || t.destination === destination))
    .filter(t => (!date || t.date === date))
    .filter(t => departureOf(t) >= now) // ไม่แสดงเที่ยวที่ออกไปแล้ว
    .sort((a, b) => departureOf(a) - departureOf(b))
    .map(withAvailability);

  res.json({ trips: result });
});

// GET /api/trips/:id
router.get('/:id', (req, res) => {
  const trip = db.trips.find(t => t.id === Number(req.params.id));
  if (!trip) return res.status(404).json({ error: 'ไม่พบเที่ยวรถ' });
  res.json({ trip: withAvailability(trip), bookedSeats: bookedSeatsOf(trip.id) });
});

module.exports = router;
module.exports.bookedSeatsOf = bookedSeatsOf;
module.exports.departureOf = departureOf;
