// routes/bookings.js - จองที่นั่ง / ดูประวัติ / ยกเลิก (ต้อง Login)
const express = require('express');
const db = require('../db');
const { requireLogin } = require('../middleware/auth');
const { bookedSeatsOf, departureOf } = require('./trips');
const router = express.Router();

router.use(requireLogin);

const MAX_SEATS_PER_BOOKING = 4;

function describe(b) {
  const trip = db.trips.find(t => t.id === b.tripId);
  return { ...b, trip: trip || null };
}

// POST /api/bookings  { tripId, seats:[1,2], passengerName, phone }
router.post('/', (req, res) => {
  const { tripId, seats, passengerName, phone } = req.body || {};
  const trip = db.trips.find(t => t.id === Number(tripId));
  if (!trip) return res.status(404).json({ error: 'ไม่พบเที่ยวรถ' });
  if (departureOf(trip) < new Date()) return res.status(400).json({ error: 'เที่ยวรถนี้ออกเดินทางไปแล้ว' });

  if (typeof passengerName !== 'string' || passengerName.trim().length < 2) {
    return res.status(400).json({ error: 'กรุณากรอกชื่อผู้โดยสาร' });
  }
  if (!/^0\d{8,9}$/.test(phone || '')) {
    return res.status(400).json({ error: 'เบอร์โทรไม่ถูกต้อง (เช่น 0812345678)' });
  }
  if (!Array.isArray(seats) || seats.length < 1 || seats.length > MAX_SEATS_PER_BOOKING) {
    return res.status(400).json({ error: `เลือกที่นั่งได้ 1-${MAX_SEATS_PER_BOOKING} ที่นั่งต่อการจอง` });
  }
  const seatNums = seats.map(Number);
  const valid = seatNums.every(s => Number.isInteger(s) && s >= 1 && s <= trip.totalSeats);
  if (!valid || new Set(seatNums).size !== seatNums.length) {
    return res.status(400).json({ error: 'หมายเลขที่นั่งไม่ถูกต้อง' });
  }

  // ตรวจที่นั่งซ้ำฝั่งเซิร์ฟเวอร์ (กันสองคนจองที่นั่งเดียวกัน)
  const taken = bookedSeatsOf(trip.id);
  const conflict = seatNums.filter(s => taken.includes(s));
  if (conflict.length) {
    return res.status(409).json({ error: `ที่นั่ง ${conflict.join(', ')} ถูกจองไปแล้ว กรุณาเลือกใหม่` });
  }

  const booking = {
    id: db.nextId('bookings'),
    userId: req.session.user.id,
    tripId: trip.id,
    seats: seatNums.sort((a, b) => a - b),
    passengerName: passengerName.trim(),
    phone,
    totalPrice: trip.price * seatNums.length,
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  db.bookings.push(booking);
  db.save();
  res.status(201).json({ booking: describe(booking) });
});

// GET /api/bookings/mine - ประวัติการจองของฉัน
router.get('/mine', (req, res) => {
  const list = db.bookings
    .filter(b => b.userId === req.session.user.id)
    .sort((a, b) => b.id - a.id)
    .map(b => ({ ...describe(b), canCancel: b.status === 'confirmed' && !!db.trips.find(t => t.id === b.tripId) && departureOf(db.trips.find(t => t.id === b.tripId)) > new Date() }));
  res.json({ bookings: list });
});

// DELETE /api/bookings/:id - ยกเลิกการจอง (เปลี่ยนสถานะเป็น cancelled)
router.delete('/:id', (req, res) => {
  const booking = db.bookings.find(b => b.id === Number(req.params.id));
  if (!booking) return res.status(404).json({ error: 'ไม่พบรายการจอง' });

  const isOwner = booking.userId === req.session.user.id;
  const isAdmin = req.session.user.role === 'admin';
  if (!isOwner && !isAdmin) return res.status(403).json({ error: 'ไม่มีสิทธิ์ยกเลิกรายการนี้' });
  if (booking.status === 'cancelled') return res.status(400).json({ error: 'รายการนี้ถูกยกเลิกไปแล้ว' });

  const trip = db.trips.find(t => t.id === booking.tripId);
  if (!isAdmin && trip && departureOf(trip) < new Date()) {
    return res.status(400).json({ error: 'เที่ยวรถออกเดินทางไปแล้ว ไม่สามารถยกเลิกได้' });
  }

  booking.status = 'cancelled';
  booking.cancelledAt = new Date().toISOString();
  db.save();
  res.json({ message: 'ยกเลิกการจองเรียบร้อย', booking: describe(booking) });
});

module.exports = router;
