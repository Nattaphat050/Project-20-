// routes/admin.js - จัดการเที่ยวรถ / ดูการจองทั้งหมด / จัดการผู้ใช้ (เฉพาะ Admin)
const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.use(requireAdmin);

function validateTrip(body) {
  const { origin, destination, date, time, price, busType, totalSeats } = body || {};
  if (!origin || !destination || !String(origin).trim() || !String(destination).trim()) return 'กรุณากรอกต้นทางและปลายทาง';
  if (String(origin).trim() === String(destination).trim()) return 'ต้นทางและปลายทางต้องไม่เหมือนกัน';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return 'วันที่ไม่ถูกต้อง';
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time || '')) return 'เวลาไม่ถูกต้อง (HH:MM)';
  if (!Number.isFinite(Number(price)) || Number(price) <= 0) return 'ราคาต้องมากกว่า 0';
  if (!busType || !String(busType).trim()) return 'กรุณากรอกประเภทรถ';
  const seats = Number(totalSeats);
  if (!Number.isInteger(seats) || seats < 4 || seats > 60) return 'จำนวนที่นั่งต้องอยู่ระหว่าง 4-60';
  return null;
}

function cleanTrip(body) {
  return {
    origin: String(body.origin).trim(), destination: String(body.destination).trim(),
    date: body.date, time: body.time, price: Number(body.price),
    busType: String(body.busType).trim(), totalSeats: Number(body.totalSeats)
  };
}

const activeBookingsOf = tripId => db.bookings.filter(b => b.tripId === tripId && b.status === 'confirmed');

// GET /api/admin/trips
router.get('/trips', (req, res) => {
  const trips = [...db.trips]
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))
    .map(t => ({ ...t, bookedCount: activeBookingsOf(t.id).reduce((n, b) => n + b.seats.length, 0) }));
  res.json({ trips });
});

// POST /api/admin/trips
router.post('/trips', (req, res) => {
  const error = validateTrip(req.body);
  if (error) return res.status(400).json({ error });
  const trip = { id: db.nextId('trips'), ...cleanTrip(req.body) };
  db.trips.push(trip);
  db.save();
  res.status(201).json({ trip });
});

// PUT /api/admin/trips/:id
router.put('/trips/:id', (req, res) => {
  const trip = db.trips.find(t => t.id === Number(req.params.id));
  if (!trip) return res.status(404).json({ error: 'ไม่พบเที่ยวรถ' });
  const error = validateTrip(req.body);
  if (error) return res.status(400).json({ error });
  const updated = cleanTrip(req.body);

  const maxBookedSeat = Math.max(0, ...activeBookingsOf(trip.id).flatMap(b => b.seats));
  if (updated.totalSeats < maxBookedSeat) {
    return res.status(409).json({ error: `มีผู้จองที่นั่งหมายเลข ${maxBookedSeat} แล้ว ลดจำนวนที่นั่งต่ำกว่านี้ไม่ได้` });
  }
  Object.assign(trip, updated);
  db.save();
  res.json({ trip });
});

// DELETE /api/admin/trips/:id
router.delete('/trips/:id', (req, res) => {
  const idx = db.trips.findIndex(t => t.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'ไม่พบเที่ยวรถ' });
  if (activeBookingsOf(db.trips[idx].id).length) {
    return res.status(409).json({ error: 'เที่ยวรถนี้มีการจองอยู่ ต้องยกเลิกการจองก่อนจึงจะลบได้' });
  }
  db.trips.splice(idx, 1);
  db.save();
  res.json({ message: 'ลบเที่ยวรถเรียบร้อย' });
});

// GET /api/admin/bookings
router.get('/bookings', (req, res) => {
  const list = [...db.bookings].sort((a, b) => b.id - a.id).map(b => {
    const user = db.users.find(u => u.id === b.userId);
    return { ...b, username: user ? user.username : '(ถูกลบ)', trip: db.trips.find(t => t.id === b.tripId) || null };
  });
  res.json({ bookings: list });
});

// GET /api/admin/users
router.get('/users', (req, res) => {
  const users = db.users.map(({ password, ...u }) => ({
    ...u, bookingCount: db.bookings.filter(b => b.userId === u.id && b.status === 'confirmed').length
  }));
  res.json({ users });
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', (req, res) => {
  const id = Number(req.params.id);
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'ไม่พบผู้ใช้' });
  if (user.id === req.session.user.id) return res.status(400).json({ error: 'ไม่สามารถลบบัญชีของตัวเองได้' });
  if (user.role === 'admin') return res.status(400).json({ error: 'ไม่สามารถลบบัญชี Admin ได้' });
  if (db.bookings.some(b => b.userId === id && b.status === 'confirmed')) {
    return res.status(409).json({ error: 'ผู้ใช้นี้มีการจองที่ยังใช้งานอยู่ ต้องยกเลิกการจองก่อน' });
  }
  db.users.splice(db.users.indexOf(user), 1);
  db.save();
  res.json({ message: 'ลบผู้ใช้เรียบร้อย' });
});

module.exports = router;
