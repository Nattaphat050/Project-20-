// db.js - ชั้นจัดเก็บข้อมูล (JSON file database)
// เก็บข้อมูล 3 collections: users, trips, bookings ไว้ที่ data/db.json
// เขียนไฟล์แบบ synchronous ทำให้การจองที่นั่งใน process เดียวไม่เกิด race condition
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_FILE = path.join(__dirname, 'data', 'db.json');

// ---------- Password hashing (scrypt + salt) ----------
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), test);
}

// ---------- Helpers ----------
function pad(n) { return String(n).padStart(2, '0'); }

function dateString(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function seedData() {
  const users = [
    { id: 1, username: 'admin', password: hashPassword('admin123'), fullName: 'ผู้ดูแลระบบ', role: 'admin', createdAt: new Date().toISOString() },
    { id: 2, username: 'user', password: hashPassword('user123'), fullName: 'สมชาย ใจดี', role: 'user', createdAt: new Date().toISOString() }
  ];

  const templates = [
    ['กรุงเทพฯ', 'เชียงใหม่', '08:00', 650, 'VIP 24 ที่นั่ง'],
    ['กรุงเทพฯ', 'เชียงใหม่', '20:30', 550, 'ชั้น 1'],
    ['กรุงเทพฯ', 'ขอนแก่น', '09:30', 420, 'ชั้น 1'],
    ['กรุงเทพฯ', 'ภูเก็ต', '18:00', 890, 'VIP 24 ที่นั่ง'],
    ['กรุงเทพฯ', 'พัทยา', '07:00', 150, 'ชั้น 2'],
    ['เชียงใหม่', 'กรุงเทพฯ', '19:00', 650, 'VIP 24 ที่นั่ง'],
    ['ขอนแก่น', 'กรุงเทพฯ', '14:00', 420, 'ชั้น 1'],
    ['นครปฐม', 'กรุงเทพฯ', '06:30', 60, 'ชั้น 2']
  ];

  const trips = [];
  let id = 1;
  for (let day = 0; day < 7; day++) {
    for (const [origin, destination, time, price, busType] of templates) {
      trips.push({
        id: id++, origin, destination, date: dateString(day), time,
        price, busType, totalSeats: busType.startsWith('VIP') ? 24 : 40
      });
    }
  }
  return { users, trips, bookings: [], counters: { users: 3, trips: id, bookings: 1 } };
}

// ---------- Load / Save ----------
let data;

function load() {
  if (!fs.existsSync(DB_FILE)) {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    data = seedData();
    save();
  } else {
    data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  }
}

function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, DB_FILE); // เขียนไฟล์ชั่วคราวก่อนแล้วค่อยแทนที่ ป้องกันไฟล์เสียหาย
}

function nextId(collection) {
  return data.counters[collection]++;
}

load();

module.exports = {
  get users() { return data.users; },
  get trips() { return data.trips; },
  get bookings() { return data.bookings; },
  nextId, save, hashPassword, verifyPassword
};
