# ระบบจองรถโดยสารออนไลน์ (Bus Booking System)

โครงงานรายวิชา Internet Programming — Web Application ด้วย HTML, CSS, JavaScript, Node.js และ Express.js

**สมาชิก:** (ใส่ชื่อ-รหัสนักศึกษา)

## วัตถุประสงค์
ช่วยให้ผู้โดยสารค้นหาเที่ยวรถ เลือกที่นั่งจากผังที่นั่ง จอง และยกเลิกการจองได้เอง
ส่วนผู้ดูแลระบบจัดการเที่ยวรถ ดูรายการจอง และจัดการผู้ใช้ได้

## Features
**User:** สมัครสมาชิก / Login / Logout • ค้นหาเที่ยวรถ (ต้นทาง ปลายทาง วันที่) และเรียงลำดับ • ดูผังที่นั่งแบบสด • จองได้สูงสุด 4 ที่นั่ง/ครั้ง • ดูประวัติ และยกเลิกการจอง

**Admin:** เพิ่ม / แก้ไข / ลบเที่ยวรถ • ดูและยกเลิกรายการจองทั้งหมด • ลบผู้ใช้

## Technologies
- Front-end: HTML5, CSS3, JavaScript, DOM Manipulation (สร้าง UI ด้วย DOM, `<dialog>` modal)
- Back-end: Node.js, Express.js (REST API)
- State: `express-session` (สถานะ Login) และ Cookies (`lastSearch`, `rememberedUser`)
- Database: ไฟล์ JSON (`data/db.json`) มี 3 collections: users, trips, bookings

## วิธีติดตั้งและ Run
ต้องมี Node.js 18 ขึ้นไป
```bash
npm install
npm start
```
เปิด http://localhost:3000 (ครั้งแรกระบบสร้าง `data/db.json` พร้อมข้อมูลตัวอย่างให้อัตโนมัติ
หากต้องการรีเซ็ตข้อมูล ให้ลบไฟล์นี้แล้วรันใหม่)

## บัญชีสำหรับทดสอบ
| บทบาท | Username | Password |
|---|---|---|
| Admin | admin | admin123 |
| User | user | user123 |

## โครงสร้างโปรเจกต์
```
app.js            เริ่มเซิร์ฟเวอร์ ตั้งค่า middleware และ route ของหน้าเว็บ
db.js             ชั้นข้อมูล (โหลด/บันทึก JSON, hash รหัสผ่านด้วย scrypt)
middleware/       auth.js ตรวจ Login / Admin จาก Session
routes/           auth, trips, bookings, admin (REST API)
views/            หน้า HTML
public/css, js/   สไตล์และสคริปต์ฝั่ง Client
docs/             System Documentation
```

## REST API
| Method | Path | คำอธิบาย | สิทธิ์ |
|---|---|---|---|
| POST | /api/auth/register | สมัครสมาชิก | - |
| POST | /api/auth/login | เข้าสู่ระบบ | - |
| POST | /api/auth/logout | ออกจากระบบ | - |
| GET | /api/auth/me | ผู้ใช้ปัจจุบัน | - |
| GET | /api/trips?origin=&destination=&date= | ค้นหาเที่ยวรถ | - |
| GET | /api/trips/:id | รายละเอียดและที่นั่งที่ถูกจอง | - |
| POST | /api/bookings | จองที่นั่ง | Login |
| GET | /api/bookings/mine | ประวัติการจอง | Login |
| DELETE | /api/bookings/:id | ยกเลิกการจอง | เจ้าของ/Admin |
| GET/POST | /api/admin/trips | ดู / เพิ่มเที่ยวรถ | Admin |
| PUT/DELETE | /api/admin/trips/:id | แก้ไข / ลบเที่ยวรถ | Admin |
| GET | /api/admin/bookings | รายการจองทั้งหมด | Admin |
| GET | /api/admin/users | รายชื่อผู้ใช้ | Admin |
| DELETE | /api/admin/users/:id | ลบผู้ใช้ | Admin |

## เอกสารประกอบ
ดู [docs/system-documentation.md](docs/system-documentation.md)
